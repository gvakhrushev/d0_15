#!/usr/bin/env bash
set -euo pipefail
# Apply all archived research to the EXISTING task branch. No force push, no merge.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="${1:?Usage: bash IMPORT_INTO_310.sh /path/to/d0_15 [--push] [--replay]}"
shift
PUSH=0; REPLAY=0
for flag in "$@"; do
  case "$flag" in --push) PUSH=1;; --replay) REPLAY=1;; *) echo "Unknown option" >&2; exit 2;; esac
done
BRANCH='exp/a4d-joint-response-resolvent'
OBSERVED='b45e32ebce6f04553e1d0212cba4c1ccf3cb78bf'
PATCH="$HERE/D0_v1_v2_v3_complete_intake.patch"
python3 - "$HERE" <<'PY'
from pathlib import Path
import hashlib,json,sys
p=Path(sys.argv[1]);m=json.loads((p/'TRANSFER.json').read_text())
b=(p/'D0_v1_v2_v3_complete_intake.patch').read_bytes()
if hashlib.sha256(b).hexdigest()!=m['patch_sha256']:raise SystemExit('PATCH_CHECKSUM_FAILED')
print('PATCH_CHECKSUM_OK')
PY
REPO="$(git -C "$REPO" rev-parse --show-toplevel)"
ORIGIN="$(git -C "$REPO" remote get-url origin)"
case "$ORIGIN" in
  https://github.com/gvakhrushev/d0_15|https://github.com/gvakhrushev/d0_15.git|git@github.com:gvakhrushev/d0_15.git|ssh://git@github.com/gvakhrushev/d0_15.git) ;;
  *) echo 'Refusing: origin is not the intended gvakhrushev/d0_15 repository.' >&2; exit 2;;
esac
CURRENT="$(git -C "$REPO" symbolic-ref --quiet --short HEAD)"
[[ "$CURRENT" == "$BRANCH" ]] || { echo "Refusing: use a clean worktree on $BRANCH." >&2; exit 2; }
[[ -z "$(git -C "$REPO" status --porcelain)" ]] || { echo 'Refusing: working tree or index is not clean.' >&2; exit 2; }
GITDIR="$(git -C "$REPO" rev-parse --absolute-git-dir)"
for item in rebase-apply rebase-merge MERGE_HEAD CHERRY_PICK_HEAD; do
 [[ ! -e "$GITDIR/$item" ]] || { echo 'Refusing: another Git operation is in progress.' >&2; exit 2; }
done
if (( PUSH )); then
 git -C "$REPO" fetch origin "$BRANCH"
 REMOTE_HEAD="$(git -C "$REPO" rev-parse FETCH_HEAD)"
 # Only update a clean behind worktree. Never publish unrelated local commits.
 git -C "$REPO" merge-base --is-ancestor HEAD "$REMOTE_HEAD" || {
  echo 'Refusing: local branch has commits not contained in current remote SOURCE.' >&2; exit 2;
 }
 git -C "$REPO" merge --ff-only "$REMOTE_HEAD"
fi
git -C "$REPO" cat-file -e "$OBSERVED^{commit}" || {
 echo 'Observed SOURCE object absent. Fetch the existing task branch first.' >&2; exit 2;
}
git -C "$REPO" merge-base --is-ancestor "$OBSERVED" HEAD || {
 echo 'Refusing: target is not a descendant of the observed SOURCE. Review first.' >&2; exit 2;
}
git -C "$REPO" -c core.autocrlf=false apply --check "$PATCH"
git -C "$REPO" -c core.autocrlf=false am --keep-cr "$PATCH"
CHECKER="$REPO/02_REGISTRY/research/certificates/a4d_local_record_to_matter_intake_check.py"
PYTHONDONTWRITEBYTECODE=1 python3 "$CHECKER" --verify-only
if (( REPLAY )); then
 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python3 "$CHECKER"
fi
if (( PUSH )); then
 # Ordinary push rejects a concurrently advanced remote; never force or reset.
 git -C "$REPO" push origin "HEAD:refs/heads/$BRANCH"
 echo 'PUSH_COMPLETED; PR remains Draft/IN_PROGRESS. CI and independent review are still required.'
else
 echo 'LOCAL_COMMIT_CREATED_ONLY; no remote publication was attempted.'
fi
git -C "$REPO" log -1 --format='%H %s'
